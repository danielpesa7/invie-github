## ¿Cómo puedo replicar el problema?
porfavor explicanos como replicar el problema paso a paso y en sistema operativo ocurre
## ¿En que versión de Invie ocurre?
Si este problema ocurre en todas las versiones porfavor tambien mencionarlo
